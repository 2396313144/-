#!/bin/bash

# 检查软件包是否已安装的函数
is_pkg_installed() {
    pkg list-installed | grep -q "^$1 "
}

is_pip_installed() {
    pip list | grep -q "$1"
}

# 打印信息函数
print_info() {
    echo -e "\033[1;36m[INFO] $1\033[0m"
}

# 打印错误函数
print_error() {
    echo -e "\033[1;31m[ERROR] $1\033[0m"
}

# 打印完成函数
print_success() {
    echo -e "\033[1;32m[SUCCESS] $1\033[0m"
}

# 自动应答函数
auto_confirm() {
    echo "$1" | grep -q "install" && return 0
    echo "$1" | grep -q "update" && return 0
    return 1
}

# 更新和升级package
print_info "更新和升级包列表..."
if (echo; yes) | pkg update && (echo; yes) | pkg upgrade -y; then
    print_success "包列表更新和升级成功"
else
    print_error "包列表更新和升级失败"
    exit 1
fi

# 安装python
if is_pkg_installed "python"; then
    print_info "python已安装，跳过"
else
    print_info "安装python..."
    if (echo; yes) | pkg install python -y; then
        print_success "python安装成功"
    else
        print_error "python安装失败"
        exit 1
    fi
fi

# 安装核心pip包 (requests, colorama, termcolor, tqdm)
core_pip_pkgs=("requests" "colorama" "termcolor" "tqdm")

for pkg in "${core_pip_pkgs[@]}"; do
    if is_pip_installed "$pkg"; then
        print_info "$pkg 已安装，跳过"
    else
        print_info "安装 $pkg..."
        if (echo; yes) | pip install "$pkg"; then
            print_success "$pkg 安装成功"
        else
            print_error "$pkg 安装失败"
            exit 1
        fi
    fi
done

# 安装git
if is_pkg_installed "git"; then
    print_info "git已安装，跳过"
else
    print_info "安装git..."
    if (echo; yes) | pkg install git -y; then
        print_success "git安装成功"
    else
        print_error "git安装失败"
        exit 1
    fi
fi

# 安装vim
if is_pkg_installed "vim"; then
    print_info "vim已安装，跳过"
else
    print_info "安装vim..."
    if (echo; yes) | pkg install vim -y; then
        print_success "vim安装成功"
    else
        print_error "vim安装失败"
        exit 1
    fi
fi

# 创建并激活虚拟环境
print_info "创建虚拟环境myenv..."
if [ -d "myenv" ]; then
    print_info "虚拟环境myenv已存在，跳过创建"
else
    if (echo; yes) | python -m venv myenv; then
        print_success "虚拟环境myenv创建成功"
    else
        print_error "虚拟环境myenv创建失败"
        exit 1
    fi
fi

# 激活虚拟环境
print_info "激活虚拟环境..."
source myenv/bin/activate

# 在虚拟环境中安装核心pip包
for pkg in "${core_pip_pkgs[@]}"; do
    if is_pip_installed "$pkg"; then
        print_info "虚拟环境中 $pkg 已安装，跳过"
    else
        print_info "在虚拟环境中安装 $pkg..."
        if (echo; yes) | pip install "$pkg"; then
            print_success "虚拟环境中 $pkg 安装成功"
        else
            print_error "虚拟环境中 $pkg 安装失败"
            exit 1
        fi
    fi
done

# 配置termux存储
print_info "配置termux存储 (请手动允许权限请求)..."
if termux-setup-storage; then
    print_success "termux存储配置成功"
else
    print_error "termux存储配置失败"
    exit 1
fi

# 第二次更新和升级package
print_info "再次更新和升级包列表..."
if (echo; yes) | pkg update && (echo; yes) | pkg upgrade -y; then
    print_success "包列表更新和升级成功"
else
    print_error "包列表更新和升级失败"
    exit 1
fi

# 安装核心pkg包 (clang, make, pkg-config, libexpat, python3)
core_pkg_pkgs=("clang" "make" "pkg-config" "libexpat" "python3")

for pkg in "${core_pkg_pkgs[@]}"; do
    if is_pkg_installed "$pkg"; then
        print_info "$pkg 已安装，跳过"
    else
        print_info "安装 $pkg..."
        if (echo; yes) | pkg install "$pkg" -y; then
            print_success "$pkg 安装成功"
        else
            print_error "$pkg 安装失败"
            exit 1
        fi
    fi
done

# 第三次更新package
print_info "第三次更新包列表..."
if (echo; yes) | pkg update; then
    print_success "包列表更新成功"
else
    print_error "包列表更新失败"
    exit 1
fi

# 第二次配置termux存储
print_info "再次配置termux存储 (请手动允许权限请求)..."
if termux-setup-storage; then
    print_success "termux存储配置成功"
else
    print_error "termux存储配置失败"
    exit 1
fi

# 安装apt和相关包
print_info "尝试安装apt和相关包..."
if is_pkg_installed "apt"; then
    print_info "apt已安装，跳过"
elif (echo; yes) | apt update && (echo; yes) | apt upgrade -y && (echo; yes) | apt install libdw -y; then
    print_success "apt和相关包安装成功"
else
    print_error "apt和相关包安装失败，可能在Termux环境中不适用"
fi


# 安装x11-repo
if is_pkg_installed "x11-repo"; then
    print_info "x11-repo已安装，跳过"
else
    print_info "安装x11-repo..."
    if (echo; yes) | pkg install x11-repo -y; then
        print_success "x11-repo安装成功"
    else
        print_error "x11-repo安装失败"
        exit 1
    fi
fi

print_success "所有组件安装完成！"