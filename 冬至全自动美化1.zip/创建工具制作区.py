import os

# 要创建的文件夹名称列表
folder_names = ["/storage/emulated/0/冬至制作区", "/storage/emulated/0/冬至制作区/自动美化存放区", "/storage/emulated/0/冬至制作区/PAK打包解包区", "/storage/emulated/0/冬至制作区/PAK打包解包区/pak", "/storage/emulated/0/冬至制作区/小包存放区", "/storage/emulated/0/冬至制作区/配置"]

# 批量创建文件夹
for name in folder_names:
    # 检查文件夹是否已存在，不存在则创建
    if not os.path.exists(name):
        os.makedirs(name)  # makedirs支持创建多级目录（如"a/b/c"）
        print(f"已创建文件夹：{name}")
    else:
        print(f"文件夹{name}已存在")

