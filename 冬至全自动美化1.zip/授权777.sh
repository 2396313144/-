# 检查当前目录是否为一个目录
if [ ! -d "$PWD" ]; then
    echo "错误：当前路径不是一个目录。"
    exit 1
fi

# 遍历当前目录及其子目录下的所有文件，并添加执行权限和设置权限为777
echo "正在为文件添加执行权限…"
find "$PWD" -type f -exec chmod 777 "{}" \; -exec chmod +x "{}" \;
echo "欢迎使用冬至全自动美化！"
sleep 0.3